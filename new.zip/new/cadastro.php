<?php
    if(isset($_POST['submit'])){

        include_once('database.php');

        $username = $_POST['username'];
        $password = $_POST['password'];
        $hashPw   = password_hash($password,PASSWORD_DEFAULT);
        $userType = $_POST['userType'];
        $fantasyName = $_POST['fantasyName'];
        $reason = $_POST['reason'];
        $email = $_POST['email'];
        $telephone = $_POST['tel'];
        $cnpj = $_POST['cnpj'];
        $state = $_POST['state'];
        $cep = $_POST['cep'];
        $address = $_POST['address'];
        $number = $_POST['num'];

        $query = mysqli_query($conexao, "INSERT INTO usuario (tipo_usuario, nome_usuario, senha, nome_fantasia, razao_social, email, telefone, cnpj, estado, cep, endereco, numero) 
                                         VALUES ('$userType', '$username', '$hashPw', '$fantasyName', '$reason', '$email', '$telephone', '$cnpj', '$state', '$cep', '$address', '$number')");

        header("Location: login.php");
    }

    require_once("./template.php");
?>
    <link rel="stylesheet" type="text/css" href="styles/style.css" >
    <link rel="stylesheet" type="text/css" href="styles/cadastroStyle.css" >
    <title>Food Waste - Cadastro</title>
</head>
<body>

<?php
    require_once("./navbar.php");
?>

    <div class="cadastro-div">
        <form action="cadastro.php" method="POST">
            <h2 class="legend">Cadastrar Usuário</h2>
            
            <input type="text" name="username" id="username" placeholder="Nome de usúario" class="inputUser required" required>
        
            <input type="password" id="password" name="password" placeholder="Senha" class="inputUser required" required>
        
            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirmar senha" class="inputUser required" required>
            
            <div class="typeDiv">
                    <input  class="btn-check" type="radio" name="userType" id="doador" value="D" checked hidden>
                    <label  class="btn btn-outline-secondary" for="doador">Doador</label>
                
                    <input  class="btn-check" type="radio" name="userType" id="receptor" value="R" hidden>
                    <label  class="btn btn-outline-secondary" for="receptor">Receptor</label>
            </div>

            <input type="text" name="fantasyName" id="fantasyName" placeholder="Nome fantasia" class="inputUser required" required>
            
            <input type="text" id="reason" name="reason" placeholder="Razão social" class="inputUser required" required>
        
            <input type="email" id="email" name="email" placeholder="E-mail" class="inputUser required" required>
        
            <input type="tel" id="tel" name="tel" placeholder="Telefone" class="inputUser required" required>

            <input type="text" id="cnpj" name="cnpj" placeholder="CNPJ" class="inputUser required" required>
        
            <input type="text" id="cep" name="cep" placeholder="CEP" class="inputUser required" required>   

            <input type="text" id="state" name="state" placeholder="Estado" class="inputUser required" required>

            <input type="text" id="address" name="address" placeholder="Endereço" class="inputUser required" required>

            <input type="text" id="num" name="num" placeholder="Número" class="inputUser required" required>

            <button id="button_send" class="buttonform" type="submit" name="submit">
               Finalizar Cadastro
            </button>
        </form>
    </div>
    
<?php
    require_once("./footer.php");
?>